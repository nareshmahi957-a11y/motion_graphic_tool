#!/usr/bin/env python
import os
import sys

print("Initializing AutoAE DaVinci Build...")

# 1. Connect to DaVinci Resolve API
try:
    import DaVinciResolveScript as dvr_script
    resolve = dvr_script.scriptapp("Resolve")
except ImportError:
    print("Error: Could not connect to DaVinci Resolve API. Ensure Resolve is open and External Scripting is set to Local.")
    sys.exit()

projectManager = resolve.GetProjectManager()
project = projectManager.GetCurrentProject()
mediaPool = project.GetMediaPool()

if not project:
    print("Please open a project in DaVinci Resolve first.")
    sys.exit()

# 2. Setup Paths
script_dir = os.path.dirname(os.path.abspath(__file__))
assets_dir = os.path.join(script_dir, "Assets")

if not os.path.exists(assets_dir):
    print(f"Error: Assets folder not found at {assets_dir}")
    sys.exit()

# 3. Create a dedicated Bin
root_folder = mediaPool.GetRootFolder()
new_bin = mediaPool.AddSubFolder(root_folder, "AutoAE_Assets_5947")
mediaPool.SetCurrentFolder(new_bin)

# 4. Import Media
files_to_import = [os.path.join(assets_dir, f) for f in os.listdir(assets_dir) if f.endswith(('.png', '.mp4', '.jpg'))]
print(f"Importing {len(files_to_import)} assets...")
imported_items = mediaPool.ImportMedia(files_to_import)

if not imported_items:
    print("No media imported. Check asset paths.")
    sys.exit()

# 5. Create Timeline
timeline_name = "AutoAE_Studio_Build"
timeline = mediaPool.CreateEmptyTimeline(timeline_name)
if not timeline:
    print("Failed to create timeline.")
    sys.exit()

project.SetCurrentTimeline(timeline)

# 6. Stack Assets on Timeline (Layering)
# We loop through imported items and drop them onto consecutive video tracks
for idx, item in enumerate(imported_items):
    clip_info = {
        "mediaPoolItem": item,
        "startFrame": 0,
        "endFrame": 120, # Matches Remotion exact duration
        "trackIndex": idx + 1,        # Stacks on V1, V2, V3...
        "mediaType": 1                # 1 = Video Type
    }
    mediaPool.AppendToTimeline([clip_info])

print("✅ AutoAE Build Complete! Check your timeline.")
