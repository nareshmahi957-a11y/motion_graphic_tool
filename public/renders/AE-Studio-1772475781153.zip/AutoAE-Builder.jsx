
app.beginUndoGroup("AutoAE Studio Build");

var compName = "AutoAE_Project_Main";
var compWidth = 1080;
var compHeight = 1920;
var mainComp = app.project.items.addComp(compName, compWidth, compHeight, 1, 10, 30);
mainComp.openInViewer();

var bgLayer = mainComp.layers.addSolid([0.17647058823529413, 0.17647058823529413, 0.17647058823529413], "Scene Background", compWidth, compHeight, 1);
bgLayer.locked = true;

// ⚡ SMART ASSET IMPORTER
// This dynamically finds the folder the user unzipped the script into!
var scriptFolder = new File($.fileName).parent.fsName;
var assetsFolder = scriptFolder + ($.os.indexOf("Windows") !== -1 ? "\\Assets" : "/Assets");

function importAsset(fileName) {
    var file = new File(assetsFolder + ($.os.indexOf("Windows") !== -1 ? "\\" : "/") + fileName);
    if (file.exists) {
        var imported = app.project.importFile(new ImportOptions(file));
        var layer = mainComp.layers.add(imported);
        return layer;
    }
    return null;
}

// 3. Import and place the Hand Assets
var palmLayer = importAsset("palm.png");
if (palmLayer) {
    palmLayer.property("Position").setValue([compWidth/2 + (-138), 200 + (-182)]);
    palmLayer.property("Rotation").setValue(6);
    // Add floating expression
    palmLayer.property("Position").expression = "var t = time; value + [Math.sin(t*2)*10, Math.cos(t*1.5)*15]";
}

// 4. Generate Text
function createTextLayer(name, textStr, fSize, fColor, yPos) {
    if (!textStr) return null;
    var tLayer = mainComp.layers.addText(textStr);
    tLayer.name = name;
    var tDoc = tLayer.property("Source Text").value;
    tDoc.fontSize = fSize;
    tDoc.fillColor = fColor;
    tDoc.justification = ParagraphJustification.CENTER_JUSTIFY;
    tLayer.property("Source Text").setValue(tDoc);
    tLayer.property("Position").setValue([compWidth/2, yPos]);
    return tLayer;
}

createTextLayer("Top Text", "Influence", 45, [1,1,1], 1300);
var mainLayer = createTextLayer("Main Text", "Master Mind", 135, [1, 1, 1], 1400);
createTextLayer("Bottom Text", "Control", 40, [1,1,1], 1500);

if (mainLayer) {
    var glow = mainLayer.Effects.addProperty("ADBE Glo2");
    glow.property("Glow Radius").setValue(80);
    glow.property("Color A").setValue([1, 1, 1]);
    glow.property("Color B").setValue([1, 1, 1]);
}

alert("AutoAE Pro: Studio Project Successfully Reconstructed!");
app.endUndoGroup();
