
app.beginUndoGroup("AutoAE Precision Rebuild");
var mainComp = app.project.items.addComp("AutoAE_Studio_Final", 1080, 1920, 1, 10, 30);
mainComp.openInViewer();

// 1. Dynamic Background
var bg = mainComp.layers.addSolid([0.17647058823529413, 0.17647058823529413, 0.17647058823529413], "AUTOAE_BG", 1080, 1920, 1);
bg.locked = true;

var folder = new File($.fileName).parent.fsName;
var assetsPath = folder + ($.os.indexOf("Windows") !== -1 ? "\\Assets\\" : "/Assets/");

function addAsset(file, name) {
    var f = new File(assetsPath + file);
    if (!f.exists) return null;
    var l = mainComp.layers.add(app.project.importFile(new ImportOptions(f)));
    l.name = name;
    return l;
}

// 2. THE RIG (Precision Knuckle Alignment)
var handX = 540 + (-138);
var handY = 300 + (-182);
var handScale = (600 / 6); 

var palm = addAsset("palm.png", "AUTOAE_PALM");
palm.property("Position").setValue([handX, handY]);
palm.property("Rotation").setValue(6);
palm.property("Scale").setValue([handScale, handScale]);
// Floating Hand Expression
palm.property("Position").expression = "value + [0, Math.sin(time*3)*20]";

function rigFinger(file, name, xPct, yPct, rot) {
    var f = addAsset(file, name);
    if (!f) return null;
    // ⚡ STEP 1: Move Anchor Point to the knuckle (far left of image)
    f.property("Anchor Point").setValue([0, f.height/2]);
    // ⚡ STEP 2: Parent BEFORE positioning to zero-out coordinates
    f.parent = palm;
    // ⚡ STEP 3: Apply percentages relative to palm width/height
    var xOff = (xPct / 100) * palm.width;
    var yOff = (yPct / 100) * palm.height;
    f.property("Position").setValue([xOff, yOff]);
    f.property("Rotation").setValue(rot);
    f.property("Scale").setValue([100, 100]); // Reset scale inherited from palm
    return f;
}

var f1 = rigFinger("finger1.png", "AUTOAE_INDEX", 14, 41, 33);
var f2 = rigFinger("finger2.png", "AUTOAE_MIDDLE", 14, 45, 33);
var f3 = rigFinger("finger3.png", "AUTOAE_RING", 8, 47, 33);
var f4 = rigFinger("finger4.png", "AUTOAE_PINKY", 33, -50, 0);

// 3. The Brain (Hero Object)
var brain = addAsset("brain.png", "AUTOAE_BRAIN");
if (brain) {
    brain.property("Position").setValue([540, 850]);
    brain.property("Position").expression = "value + [0, Math.sin(time*2.5)*35]";
    var g = brain.Effects.addProperty("ADBE Glo2");
    g.property("Glow Radius").setValue(60);
    g.property("Color A").setValue([1, 1, 1]);
}

// 4. Connecting Strings (Beam Logic)
function addString(name, startLayer, endLayer) {
    var s = mainComp.layers.addSolid([1,1,1], name, 1080, 1920, 1);
    var b = s.Effects.addProperty("ADBE Beam");
    b.property("Starting Point").expression = "thisComp.layer('" + startLayer.name + "').transform.position";
    b.property("Ending Point").expression = "thisComp.layer('" + endLayer.name + "').transform.position";
    b.property("Starting Thickness").setValue(2.5);
    b.property("Ending Thickness").setValue(1);
    b.property("Inside Color").setValue([1,1,1]);
    s.moveAfter(palm);
}

if(f1 && brain) addString("STRING_INDEX", f1, brain);
if(f2 && brain) addString("STRING_MIDDLE", f2, brain);

// 5. Spring Animated Text
function addText(str, size, col, y, delay) {
    if(!str) return;
    var t = mainComp.layers.addText(str);
    var p = t.property("Source Text");
    var d = p.value;
    d.fontSize = size; d.fillColor = col; d.justification = ParagraphJustification.CENTER_JUSTIFY;
    p.setValue(d);
    t.property("Position").setValue([540, y]);
    t.property("Scale").expression = "var d="+delay+"; if(time<d){[0,0]}else{var t=time-d; var w=100*Math.cos(2.5*t*2*Math.PI)/Math.exp(4*t); [100-w,100-w]}";
}

addText("Influence", 45, [1,1,1], 1350, 0);
addText("Master Mind", 135, [1, 1, 1], 1450, 0.2);
addText("Control", 40, [1,1,1], 1550, 0.4);

alert("AutoAE Pro: Zero-Effort Studio Rig Complete!");
app.endUndoGroup();
