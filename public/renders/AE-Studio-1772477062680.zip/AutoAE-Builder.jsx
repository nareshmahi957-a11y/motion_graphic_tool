
app.beginUndoGroup("AutoAE Precision Build");
var mainComp = app.project.items.addComp("AutoAE_Final", 1080, 1920, 1, 10, 30);
mainComp.openInViewer();

var bg = mainComp.layers.addSolid([0.17647058823529413, 0.17647058823529413, 0.17647058823529413], "BG", 1080, 1920, 1);

var folder = new File($.fileName).parent.fsName;
var assetsPath = folder + ($.os.indexOf("Windows") !== -1 ? "\\Assets\\" : "/Assets/");

function addAsset(name, layerName) {
    var f = new File(assetsPath + name);
    if (!f.exists) return null;
    var l = mainComp.layers.add(app.project.importFile(new ImportOptions(f)));
    l.name = layerName;
    return l;
}

// 2. THE RIG (Using your exact Template Math)
var handSize = 600;
var centerX = 540 + (-138);
var centerY = 300 + (-182);

// Create Palm
var palm = addAsset("palm.png", "Palm");
palm.property("Position").setValue([centerX, centerY]);
palm.property("Rotation").setValue(6);
palm.property("Scale").setValue([handSize/6, handSize/6]); // Normalize scale

// Create Fingers with Template Offsets
function rigFinger(file, name, xPct, yPct, rot) {
    var f = addAsset(file, name);
    f.parent = palm;
    // Map percentages to pixel offsets relative to palm center
    var xOff = (xPct / 100) * palm.width;
    var yOff = (yPct / 100) * palm.height;
    f.property("Position").setValue([xOff, yOff]);
    f.property("Rotation").setValue(rot);
    return f;
}

// These values match your Animations.tsx precisely
var f1 = rigFinger("finger1.png", "Index", 14, 41, 33);
var f2 = rigFinger("finger2.png", "Middle", 14, 45, 33);
var f3 = rigFinger("finger3.png", "Ring", 8, 47, 33);
var f4 = rigFinger("finger4.png", "Pinky", 33, -50, 0);

// 3. The Brain
var brain = addAsset("brain.png", "Brain");
brain.property("Position").setValue([540, 800]);
brain.property("Position").expression = "value + [0, Math.sin(time*2.5)*30]";

// 4. Strings
function addString(startLayer, endLayer) {
    var s = mainComp.layers.addSolid([1,1,1], "String", 1080, 1920, 1);
    var b = s.Effects.addProperty("ADBE Beam");
    b.property("Starting Point").expression = "thisComp.layer('" + startLayer.name + "').transform.position";
    b.property("Ending Point").expression = "thisComp.layer('" + endLayer.name + "').transform.position";
    b.property("Starting Thickness").setValue(2);
    b.property("Ending Thickness").setValue(1);
}

if(f1 && brain) addString(f1, brain);
if(f2 && brain) addString(f2, brain);

// 5. Text
function addText(str, size, col, y, delay) {
    var t = mainComp.layers.addText(str);
    var p = t.property("Source Text");
    var d = p.value;
    d.fontSize = size; d.fillColor = col; d.justification = ParagraphJustification.CENTER_JUSTIFY;
    p.setValue(d);
    t.property("Position").setValue([540, y]);
    t.property("Scale").expression = "var d="+delay+"; if(time<d){[0,0]}else{var t=time-d; var w=100*Math.cos(2.5*t*2*Math.PI)/Math.exp(4*t); [100-w,100-w]}";
}

addText("Influence", 45, [1,1,1], 1300, 0);
addText("Master Mind", 135, [1, 1, 1], 1420, 0.2);
addText("Control", 40, [1,1,1], 1520, 0.4);

alert("AutoAE Pro: Precision Rig Complete!");
app.endUndoGroup();
