
app.beginUndoGroup("AutoAE Full Build");
var mainComp = app.project.items.addComp("AutoAE_Final", 1080, 1920, 1, 10, 30);
mainComp.openInViewer();

// 1. Background
var bg = mainComp.layers.addSolid([0.17647058823529413, 0.17647058823529413, 0.17647058823529413], "BG", 1080, 1920, 1);
bg.locked = true;

// 2. Asset Importer
var folder = new File($.fileName).parent.fsName;
var assetsPath = folder + ($.os.indexOf("Windows") !== -1 ? "\\Assets\\" : "/Assets/");

function addAsset(name, x, y, rot, parentLayer) {
    var f = new File(assetsPath + name);
    if (!f.exists) return null;
    var layer = mainComp.layers.add(app.project.importFile(new ImportOptions(f)));
    layer.property("Position").setValue([x, y]);
    layer.property("Rotation").setValue(rot);
    if (parentLayer) layer.parent = parentLayer;
    return layer;
}

// 3. The Puppet Master Rig
var centerX = 540 + (-138);
var centerY = 300 + (-182);

var palm = addAsset("palm.png", centerX, centerY, 6, null);
if(palm) {
    palm.property("Position").expression = "value + [0, Math.sin(time*3)*15]"; // Floating Hand
}

// Rig Fingers
var f1 = addAsset("finger1.png", 540, 960, 33, palm); // Index
var f2 = addAsset("finger2.png", 540, 960, 33, palm); // Middle
var f3 = addAsset("finger3.png", 540, 960, 33, palm); // Ring
var f4 = addAsset("finger4.png", 540, 960, 0, palm);  // Pinky

// 4. The Brain
var brain = addAsset("brain.png", 540, 800, 0, null);
if(brain) {
    brain.property("Position").expression = "value + [0, Math.sin(time*2.5)*20]";
    var g = brain.Effects.addProperty("ADBE Glo2");
    g.property("Glow Radius").setValue(50);
}

// 5. Animated Text with Spring Expression
function addText(str, size, col, y, delay) {
    if(!str) return;
    var t = mainComp.layers.addText(str);
    var p = t.property("Source Text");
    var d = p.value;
    d.fontSize = size; d.fillColor = col; d.justification = ParagraphJustification.CENTER_JUSTIFY;
    p.setValue(d);
    t.property("Position").setValue([540, y]);
    
    // Spring Animation Expression
    t.property("Scale").expression = "var d="+delay+"; if(time<d){[0,0]}else{var t=time-d; var w=100*Math.cos(2.5*t*2*Math.PI)/Math.exp(4*t); [100-w,100-w]}";
}

addText("Influence", 45, [1,1,1], 1300, 0);
addText("Master Mind", 135, [1, 1, 1], 1420, 0.2);
addText("Control", 40, [1,1,1], 1520, 0.4);

// 6. Connecting Strings (Beams)
function addString(start, end) {
    var s = mainComp.layers.addSolid([1,1,1], "String", 1080, 1920, 1);
    var b = s.Effects.addProperty("ADBE Beam");
    b.property("Starting Point").expression = "thisComp.layer('" + start.name + "').transform.position";
    b.property("Ending Point").expression = "thisComp.layer('" + end.name + "').transform.position";
    b.property("Starting Thickness").setValue(2);
    b.property("Ending Thickness").setValue(1);
}

if(f1 && brain) addString(f1, brain);
alert("AutoAE Pro: Full Rig Complete!");
app.endUndoGroup();
